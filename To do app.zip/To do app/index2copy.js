$(document).ready(function () {
    var sstart = $("#slidestart").text();
    var send = $("#slideend").text();
  
    $("#dateSlider").slider({
      range: true,
      min: -15,
      minRange: 5,
      max: 60,
      step: 1,
      values: [sstart, send],
      slide: function (event, ui) {
        if (ui.values[1] - ui.values[0] < 5) {
          // do not allow change
          // alert("select again")
  
          $("#dateSlider").off("click");
        } else {
          // allow change
          $("#slidestart").text(ui.values[0]);
          $("#slideend").text(ui.values[1]);
        }
      },
    });
  
    $("#save").click(function () {
      var taskname = $("#name").val();
      var detail = $("#description").val();
     
       var id = $('table tr:last').attr('id');
  
      let assignIndesx = 0;
      var index = 0;
     
  
      if (id != "table-head") {
        assignIndesx = parseInt(id) + 1;
      } else {
        assignIndesx = index + 1;
      }
  
      // var id=$('#table1 ').children().children().length+1;
      // debugger
      // {
      //     $('#table1 ').find("tr").last().attr('id');
  
      // }
      // else{
  
      // }
  
      var str =
        "<tr id=" +
        assignIndesx +
        ">" +
        "<td>" +
        assignIndesx +
        "</td>" +
        "<td class='task-name'>" +
        taskname +
        "</td> <td class='task-detail'>" +
        detail +
        "</td> <td><button class='editbtn'id=" +
        assignIndesx +
        " rel=" +
        assignIndesx +
        " >Edit</button><button class='delete' id=" +
        assignIndesx +
        ">Delete</button></tr> ";
  
      $("#table1").append(str);
    });
  
    $(".editbtn").click(function (event) {
      var sr = $("#table1").find(event.target.id + " was clicked");
      var mt = $(this).attr("id");
      var taskName = $(this).parents("tr").find(".task-name").html();
      var detail = $(this).parents("tr").find(".task-detail").html();
  
      //  $(".editbtn").click(function(){
      $(".container").css("display", "none");
      $(".container2").css("display", "block");
      $(".hidden-text").css("display", "block");
  
      var f = $("#fname").val(taskName);
      var g = $("#editdescp").val(detail);
  
      var et = $(this).attr("id");
      $(".hidden-text").val(et);
  
      // })
    });
    $(".delete").click(function (event) {
      $("#table1").find(event.target.id + " was clicked");
  
      // $(".container").css("display", "none");
      // $(".container2").css("display", "block");
      // $(".hidden-text").css("display", "block");
      var mt = $(this).attr("id");
      $(this).parents("tr").remove();
      // $('#'+del).find().remove()
      debugger;
    });
  
    $("#update").click(function () {
      var taskUpdate = $("#fname").val();
      var detailUpdate = $("#editdescp").val();
      var hiddenId = $(".hidden-text").val();
  
      $("#" + hiddenId)
        .find(".task-name")
        .html(taskUpdate);
  
      $("#" + hiddenId)
        .find(".task-detail")
        .html(detailUpdate);
  
      $(".container").css("display", "block");
      $(".container2").css("display", "none");
    });
    $("#cancel").click(function () {
      $(".container").css("display", "block");
      $(".container2").css("display", "none");
    });
  });
  