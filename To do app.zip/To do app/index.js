$(document).ready(function () {
  var exSlider = new Slider("#exampleRange");
  exSlider.on("slide", function (minPValue, betPValue) {
    $("#minP").text(+$("#minP").val(minPValue[0]));
    var p = $("#betP").text(+$("#betP").val(minPValue[1]));

    $("#minP").text(minPValue[0]);

    console.log(minPValue);

    var g = $("#betP").text(minPValue[1]);
  });

  $("#save").click(function () {
    var taskname = $("#name").val();
    var detail = $("#description").val();
    let id = $("#table1 ").find("tr").last().attr("id");
    let assignIndesx = 0;
    var index = 0;

    if (id != "table-head") {
      assignIndesx = parseInt(id) + 1;
    } else {
      assignIndesx = index + 1;
    }

    var str =
      "<tr id=" +
      assignIndesx +
      ">" +
      "<td>" +
      assignIndesx +
      "</td>" +
      "<td class='task-name'>" +
      taskname +
      "</td> <td class='task-detail'>" +
      detail +
      "</td> <td><button class='editbtn'id=" +
      assignIndesx +
      " rel=" +
      assignIndesx +
      " >Edit</button><button class='delete' id=" +
      assignIndesx +
      ">Delete</button></tr> ";

    $("#table1").append(str);
  });

  $(document).on("click", ".editbtn", function (event) {
    var sr = $("#table1").find(event.target.id + " was clicked");
    var mt = $(this).attr("id");
    var taskName = $(this).parents("tr").find(".task-name").html();
    var detail = $(this).parents("tr").find(".task-detail").html();

    $(".box1").css("display", "none");
    $(".box2").css("display", "block");
    $(".hidden-text").css("display", "block");

    var f = $("#fname").val(taskName);
    var g = $("#editdescp").val(detail);

    var et = $(this).attr("id");
    $(".hidden-text").val(et);
  });
  $(document).on("click", ".delete", function (event) {
    $("#table1").find(event.target.id + " was clicked");

    var mt = $(this).attr("id");
    $(this).parents("tr").remove();
  });

  $("#update").on("click", function () {
    var taskUpdate = $("#fname").val();
    var detailUpdate = $("#editdescp").val();
    var hiddenId = $(".hidden-text").val();

    $("#" + hiddenId)
      .find(".task-name")
      .html(taskUpdate);

    $("#" + hiddenId)
      .find(".task-detail")
      .html(detailUpdate);

    $(".box1").css("display", "block");
    $(".box2").css("display", "none");
  });
  $("#cancel").click(function () {
    $(".box1").css("display", "block");
    $(".box2").css("display", "none");
  });

  $("#showResult").click(function () {
    var x = $("#minP").text();
    var z = $("#betP").text();

    var rowhide = $("#table1 ").find("tr").last().attr("id");
    //  $("#table1 ").find("tr").last().css('display','none');

    $("#" + 3).css("display", "none");

    for (i = 1; i <= rowhide; i++) {
      if (i >= x && i <= z) {
        $("#" + i).css("display", "block");
      } else {
        $("#" + i).css("display", "none");
      }
    }
  });
});
